# Ethereal Beauty Lounge · App de citas (PWA)

## Archivos
index.html · config.js · manifest.webmanifest · sw.js · icon-192.png · icon-512.png · icon-maskable-512.png · apple-touch-icon.png · supabase.sql

## 1. Supabase (base de datos)
1. Crea un proyecto nuevo en supabase.com (recomendado: separado del POS del restaurante).
2. SQL Editor → abre `supabase.sql`, cambia `TU-CORREO@EJEMPLO.COM` por tu correo → Run.
3. Authentication → Users → Add user: tu correo y una contraseña (marca "Auto confirm").
4. Authentication → Sign In / Providers → Email: **desactiva "Allow new users to sign up"**.
5. Project Settings → API: copia **Project URL** y la llave **anon public**.

## 2. config.js
Pon la URL, la anon key y el WhatsApp del salón (505XXXXXXXX). Guarda.

## 3. GitHub
Repositorio nuevo (ej. `ethereal-citas`) → Add file → Upload files → sube TODOS los archivos de esta carpeta (sin `LEEME.md` si quieres) → Commit.

## 4. Vercel
Add New → Project → importa el repo → Framework Preset: **Other** → sin build command → Deploy.

## 5. Instalar
- Android (Chrome): botón "Instalar app" en la pantalla de bienvenida, o menú ⋮ → Instalar app.
- iPhone (Safari): Compartir → Añadir a pantalla de inicio.

## Tu agenda
Abre `https://TU-SITIO.vercel.app/#agenda`, aparece el selector Reservar | Agenda, entra con tu correo y contraseña.
Guarda ese enlace en favoritos o instala la app desde él.

## Notas
- Si cambias archivos y no se ven, cierra y abre la app (el service worker pide siempre la última versión).
- Si no hay internet o falla la base, la clienta igual puede enviar su solicitud por WhatsApp.
- Las observaciones y el teléfono solo los ves tú (protegidos por RLS); las clientas solo ven qué horas están ocupadas.
