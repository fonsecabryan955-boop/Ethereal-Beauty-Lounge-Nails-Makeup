-- ETHEREAL BEAUTY LOUNGE · base de datos de citas
-- Pega TODO esto en Supabase → SQL Editor → Run.
-- ANTES de correrlo: cambia TU-CORREO@EJEMPLO.COM (abajo) por el correo con el que vas a entrar a la agenda.

create extension if not exists btree_gist;

create table if not exists public.citas (
  id uuid primary key default gen_random_uuid(),
  creada timestamptz not null default now(),
  fecha date not null,
  inicio int not null check (inicio >= 540 and inicio < 1080),   -- minutos desde medianoche (9:00 a. m. = 540)
  fin int not null check (fin > inicio and fin <= 1080),         -- 6:00 p. m. = 1080
  minutos int not null check (minutos > 0),
  cliente text not null check (char_length(cliente) between 1 and 80),
  telefono text not null check (char_length(telefono) between 7 and 20),
  observaciones text check (char_length(observaciones) <= 500),
  turnos jsonb not null,
  total int not null default 0,
  maquillaje_por_confirmar boolean not null default false,
  estado text not null default 'confirmada' check (estado in ('confirmada','cancelada','completada')),
  -- sin citas en la pausa de 12:00 a 1:00 p. m.
  constraint sin_pausa check (not (inicio < 780 and fin > 720)),
  -- sin domingos
  constraint sin_domingos check (extract(dow from fecha) <> 0),
  -- la base de datos misma impide que dos citas se crucen
  constraint sin_cruces exclude using gist (fecha with =, int4range(inicio, fin) with &&) where (estado <> 'cancelada')
);

create index if not exists citas_fecha_idx on public.citas (fecha, inicio);

-- Solo la dueña (por correo) puede ver y administrar las citas
create or replace function public.es_duena() returns boolean
language sql stable as $$
  select coalesce((auth.jwt() ->> 'email') = 'TU-CORREO@EJEMPLO.COM', false)
$$;

alter table public.citas enable row level security;

drop policy if exists "publico reserva" on public.citas;
drop policy if exists "duena ve" on public.citas;
drop policy if exists "duena edita" on public.citas;
drop policy if exists "duena borra" on public.citas;

create policy "publico reserva" on public.citas for insert to anon, authenticated
  with check (estado = 'confirmada' and fecha >= current_date);
create policy "duena ve" on public.citas for select to authenticated using (public.es_duena());
create policy "duena edita" on public.citas for update to authenticated using (public.es_duena()) with check (public.es_duena());
create policy "duena borra" on public.citas for delete to authenticated using (public.es_duena());

revoke select on public.citas from anon;

-- Vista pública: solo horas ocupadas, sin nombres ni teléfonos
create or replace view public.citas_ocupadas as
  select fecha, inicio, fin
  from public.citas
  where estado <> 'cancelada' and fecha >= current_date;

grant select on public.citas_ocupadas to anon, authenticated;
