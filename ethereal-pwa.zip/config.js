// Completa estos 3 datos y sube este archivo a GitHub (reemplaza el existente).
window.APP_CONFIG = {
  SUPABASE_URL: "https://TU-PROYECTO.supabase.co",
  SUPABASE_ANON_KEY: "TU-ANON-KEY",
  WHATSAPP: "505XXXXXXXX" // número del salón con código de país, solo dígitos
};
